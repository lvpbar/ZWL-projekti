// popup.js
document.addEventListener("DOMContentLoaded", () => {
  const statusMessage = document.getElementById("statusMessage");
  const sendBtn = document.getElementById("sendEmailsBtn");

  sendBtn.addEventListener("click", async () => {
    statusMessage.textContent = "🚀 Starting bulk send...";
    chrome.runtime.sendMessage({ action: "sendBulkEmails" }, (response) => {
      if (!response) {
        statusMessage.textContent = "⚠️ No response from background script.";
        return;
      }
      if (response.status === "ok") {
        statusMessage.textContent = "✅ All emails sent successfully!";
      } else {
        statusMessage.textContent = "❌ " + response.message;
      }
    });
  });
});
