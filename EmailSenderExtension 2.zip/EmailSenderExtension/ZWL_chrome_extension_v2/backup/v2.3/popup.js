// popup.js

document.addEventListener("DOMContentLoaded", () => {
  const statusMessage = document.getElementById("statusMessage");

  // ✅ Replace with your actual Google Drive file URLs
  const csvDriveUrl =
    "https://drive.google.com/file/d/1lhDs6sZ_GkIYBnAh_LiuJC0GT7EV6TUn/view?usp=sharing";
  const htmlDriveUrl =
    "https://drive.google.com/file/d/1w6etq94bceqxsL99Ji_rB1jtFVhYIVqS/view?usp=sharing";

  // --- Edit CSV button ---
  document.getElementById("editCsvBtn").addEventListener("click", () => {
    statusMessage.textContent = "Opening CSV file in Google Drive...";
    chrome.tabs.create({ url: csvDriveUrl }); // Opens CSV in new tab
  });

  // --- Edit HTML Template button ---
  document.getElementById("editTemplateBtn").addEventListener("click", () => {
    statusMessage.textContent = "Opening HTML template in Google Drive...";
    chrome.tabs.create({ url: htmlDriveUrl }); // Opens HTML template
  });

  // --- Send Emails button (placeholder for next step) ---
  document.getElementById("sendEmailsBtn").addEventListener("click", () => {
    statusMessage.textContent = "🚀 Sending emails... (coming soon)";
  });
});
