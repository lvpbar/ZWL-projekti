// background.js
// Handles Google OAuth2, Drive fetch, and Gmail sending

let accessToken = null;

// --- Authenticate ---
async function getAccessToken(interactive = true) {
  return new Promise((resolve, reject) => {
    chrome.identity.getAuthToken({ interactive }, (token) => {
      if (chrome.runtime.lastError || !token) {
        reject(chrome.runtime.lastError);
      } else {
        accessToken = token;
        resolve(token);
      }
    });
  });
}

// --- Fetch file content from Google Drive ---
async function fetchDriveFile(fileId) {
  if (!accessToken) await getAccessToken();

  const res = await fetch(
    `https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`,
    {
      headers: { Authorization: `Bearer ${accessToken}` },
    }
  );
  if (!res.ok) throw new Error("Failed to fetch file");
  return await res.text();
}

// --- Send email via Gmail API ---
async function sendEmail(recipient, subject, htmlBody) {
  if (!accessToken) await getAccessToken();

  const message =
    [
      `To: ${recipient}`,
      "Subject: " + subject,
      "Content-Type: text/html; charset=UTF-8",
      "",
      htmlBody,
    ].join("\n");

  const encodedMessage = btoa(message)
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/, "");

  const res = await fetch(
    "https://www.googleapis.com/gmail/v1/users/me/messages/send",
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ raw: encodedMessage }),
    }
  );

  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error?.message || "Failed to send email");
  }
  return await res.json();
}

// --- Message listener ---
chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
  if (req.action === "sendEmails") {
    (async () => {
      try {
        const csvId = "1lhDs6sZ_GkIYBnAh_LiuJC0GT7EV6TUn"; // your CSV file
        const htmlId = "1w6etq94bceqxsL99Ji_rB1jtFVhYIVqS"; // your HTML template

        const [csv, html] = await Promise.all([
          fetchDriveFile(csvId),
          fetchDriveFile(htmlId),
        ]);

        sendResponse({ status: "ok", csv, html });
      } catch (err) {
        sendResponse({ status: "error", message: err.message });
      }
    })();
    return true;
  }

  if (req.action === "sendSingleEmail") {
    (async () => {
      try {
        const result = await sendEmail(
          req.recipient,
          req.subject,
          req.htmlBody
        );
        sendResponse({ status: "ok", result });
      } catch (err) {
        sendResponse({ status: "error", message: err.message });
      }
    })();
    return true;
  }
});
