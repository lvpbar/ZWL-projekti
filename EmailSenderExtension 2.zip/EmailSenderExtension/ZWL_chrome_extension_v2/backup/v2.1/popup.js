// popup.js
// This file handles all interactions in the popup UI

// Wait until DOM is fully loaded
document.addEventListener("DOMContentLoaded", () => {
  // Button elements
  const editTemplateBtn = document.getElementById("editTemplateBtn");
  const editCsvBtn = document.getElementById("editCsvBtn");
  const sendEmailsBtn = document.getElementById("sendEmailsBtn");
  const statusMessage = document.getElementById("statusMessage");

  // --- Button Handlers ---

  // 1️⃣ Edit HTML Template
  editTemplateBtn.addEventListener("click", () => {
    statusMessage.textContent = "Opening HTML template editor...";
    chrome.runtime.sendMessage({ action: "editTemplate" });
  });

  // 2️⃣ Edit CSV
  editCsvBtn.addEventListener("click", () => {
    statusMessage.textContent = "Opening CSV editor...";
    chrome.runtime.sendMessage({ action: "editCsv" });
  });

  // 3️⃣ Send Emails
  sendEmailsBtn.addEventListener("click", () => {
    statusMessage.textContent = "Starting email sending process...";
    chrome.runtime.sendMessage({ action: "sendEmails" });
  });

  // --- Listen for updates from background.js ---
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === "status") {
      statusMessage.textContent = msg.text;
    } else if (msg.type === "error") {
      statusMessage.textContent = "❌ " + msg.text;
    } else if (msg.type === "success") {
      statusMessage.textContent = "✅ " + msg.text;
    }
  });
});
