// background.js
// This is a placeholder background script for the Gmail Bulk Sender extension.
// It listens for messages from popup.js and logs them for now.

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log("Background received:", request);

  if (request.action === "editTemplate") {
    // Placeholder: open an editor UI or file picker later
    sendResponse({ status: "ok", message: "HTML Template editing coming soon!" });
  }

  if (request.action === "editCsv") {
    sendResponse({ status: "ok", message: "CSV editing coming soon!" });
  }

  if (request.action === "sendEmails") {
    sendResponse({ status: "ok", message: "Email sending logic coming soon!" });
  }

  return true; // Keeps message channel open for async replies if needed
});
