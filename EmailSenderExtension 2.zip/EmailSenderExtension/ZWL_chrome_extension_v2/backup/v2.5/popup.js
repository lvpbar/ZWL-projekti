// popup.js
document.addEventListener("DOMContentLoaded", () => {
  const statusMessage = document.getElementById("statusMessage");
  const sendBtn = document.getElementById("sendEmailsBtn");
  const googleAuthBtn = document.getElementById("googleAuthBtn");
  const editCsvBtn = document.getElementById("editCsvBtn");
  const editTemplateBtn = document.getElementById("editTemplateBtn");

  // --- Google Drive File IDs ---
  const CSV_FILE_ID = "1lhDs6sZ_GkIYBnAh_LiuJC0GT7EV6TUn";
  const HTML_FILE_ID = "1w6etq94bceqxsL99Ji_rB1jtFVhYIVqS";

  // =========================
  //  Utility functions
  // =========================

  // Open file in Google Drive
  function openDriveFile(fileId) {
    const url = `https://drive.google.com/open?id=${fileId}`;
    chrome.tabs.create({ url });
  }

  // Get a new OAuth token
  function getAuthToken(interactive = true) {
    return new Promise((resolve, reject) => {
      chrome.identity.getAuthToken({ interactive }, (token) => {
        if (chrome.runtime.lastError || !token) {
          reject(chrome.runtime.lastError);
        } else {
          resolve(token);
        }
      });
    });
  }

  // Fetch user info (email)
  async function fetchUserEmail(token) {
    const res = await fetch("https://www.googleapis.com/oauth2/v2/userinfo", {
      headers: { Authorization: "Bearer " + token },
    });
    if (!res.ok) throw new Error("Failed to fetch user info");
    const data = await res.json();
    return data.email;
  }

  // Log out (revoke token)
  function logoutUser(token) {
    return new Promise((resolve) => {
      if (!token) return resolve();
      // Revoke OAuth token with Google
      fetch(`https://accounts.google.com/o/oauth2/revoke?token=${token}`).finally(() => {
        chrome.identity.removeCachedAuthToken({ token }, () => {
          chrome.storage.local.remove("userEmail", () => {
            resolve();
          });
        });
      });
    });
  }

  // =========================
  //  UI handlers
  // =========================

  // Edit buttons
  if (editCsvBtn) {
    editCsvBtn.addEventListener("click", () => {
      statusMessage.textContent = "📂 Opening CSV file in Google Drive...";
      openDriveFile(CSV_FILE_ID);
    });
  }

  if (editTemplateBtn) {
    editTemplateBtn.addEventListener("click", () => {
      statusMessage.textContent = "📂 Opening HTML template in Google Drive...";
      openDriveFile(HTML_FILE_ID);
    });
  }

  // --- Login / Logout button ---
  let currentToken = null;

  async function updateLoginState() {
    chrome.storage.local.get("userEmail", (data) => {
      if (data.userEmail) {
        googleAuthBtn.textContent = `🚪 Log out (${data.userEmail})`;
        statusMessage.textContent = `✅ Logged in as ${data.userEmail}`;
      } else {
        googleAuthBtn.textContent = "🔐 Sign in with Google";
        statusMessage.textContent = "Not logged in.";
      }
    });
  }

  if (googleAuthBtn) {
    googleAuthBtn.addEventListener("click", async () => {
      try {
        const { userEmail } = await new Promise((resolve) =>
          chrome.storage.local.get("userEmail", resolve)
        );

        // If user is logged in → Log out
        if (userEmail) {
          statusMessage.textContent = "🚪 Logging out...";
          await logoutUser(currentToken);
          currentToken = null;
          googleAuthBtn.textContent = "🔐 Sign in with Google";
          statusMessage.textContent = "You are now logged out.";
          await updateLoginState();
          return;
        }

        // If user is not logged in → Log in
        statusMessage.textContent = "🔐 Signing in...";
        const token = await getAuthToken(true);
        currentToken = token;

        const email = await fetchUserEmail(token);
        chrome.storage.local.set({ userEmail: email });
        googleAuthBtn.textContent = `🚪 Log out (${email})`;
        statusMessage.textContent = `✅ Logged in as ${email}`;
        console.log("Logged in as", email);
      } catch (err) {
        console.error("Login error:", err);
        statusMessage.textContent = "❌ Login failed.";
      }
    });
  }

  // --- Send emails button (unchanged) ---
  if (sendBtn) {
    sendBtn.addEventListener("click", async () => {
      statusMessage.textContent = "🚀 Starting bulk send...";
      chrome.runtime.sendMessage({ action: "sendBulkEmails" }, (response) => {
        if (!response) {
          statusMessage.textContent = "⚠️ No response from background script.";
          return;
        }
        if (response.status === "ok") {
          statusMessage.textContent = "✅ All emails sent successfully!";
        } else {
          statusMessage.textContent = "❌ " + response.message;
        }
      });
    });
  }

  // Check stored login state when popup opens
  updateLoginState();
});
