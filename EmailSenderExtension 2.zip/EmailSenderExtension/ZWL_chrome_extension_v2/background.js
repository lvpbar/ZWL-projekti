// background.js (Manifest V3 service worker)

const CSV_FILE_ID = "1lhDs6sZ_GkIYBnAh_LiuJC0GT7EV6TUn";   // your Drive CSV file ID
const HTML_FILE_ID = "1w6etq94bceqxsL99Ji_rB1jtFVhYIVqS";  // your Drive HTML template ID

// ---- Utility: get Google OAuth access token ----
async function getAccessToken(interactive = true) {
  return new Promise((resolve, reject) => {
    chrome.identity.getAuthToken({ interactive }, (token) => {
      if (chrome.runtime.lastError || !token) {
        reject(chrome.runtime.lastError);
      } else resolve(token);
    });
  });
}

// ---- Utility: fetch file content from Drive ----
async function getDriveFileContent(fileId, token) {
  const res = await fetch(
    `https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`,
    { headers: { Authorization: `Bearer ${token}` } }
  );
  if (!res.ok) throw new Error(`Drive fetch failed: ${res.statusText}`);
  return await res.text();
}

// ---- Utility: build MIME message (plain + HTML + optional attachment) ----
async function buildMime({ to, subject, htmlBody, attachment }) {
  const boundary = "----=_Part_" + Math.random().toString(36).slice(2);
  let mime = `To: ${to}\r\nSubject: ${subject}\r\n`;
  mime += `MIME-Version: 1.0\r\n`;
  if (attachment) {
    mime += `Content-Type: multipart/mixed; boundary="${boundary}"\r\n\r\n`;
    mime += `--${boundary}\r\n`;
    mime += `Content-Type: text/html; charset="UTF-8"\r\n\r\n`;
    mime += `${htmlBody}\r\n\r\n`;
    mime += `--${boundary}\r\n`;
    mime += `Content-Type: ${attachment.type}; name="${attachment.name}"\r\n`;
    mime += "Content-Transfer-Encoding: base64\r\n";
    mime += `Content-Disposition: attachment; filename="${attachment.name}"\r\n\r\n`;
    mime += `${attachment.content}\r\n\r\n`;
    mime += `--${boundary}--`;
  } else {
    mime += `Content-Type: text/html; charset="UTF-8"\r\n\r\n${htmlBody}`;
  }
  return mime;
}

function base64urlEncode(str) {
  const b64 = btoa(unescape(encodeURIComponent(str)));
  return b64.replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

// ---- Gmail API send ----
async function sendEmail({ to, subject, htmlBody, attachment, token }) {
  const mime = await buildMime({ to, subject, htmlBody, attachment });
  const raw = base64urlEncode(mime);
  const res = await fetch("https://www.googleapis.com/gmail/v1/users/me/messages/send", {
    method: "POST",
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    body: JSON.stringify({ raw }),
  });
  if (!res.ok) throw new Error(await res.text());
  return await res.json();
}

// ---- Listen for popup messages ----
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "sendBulkEmails") {
    handleBulkSend().then(
      () => sendResponse({ status: "ok" }),
      (err) => sendResponse({ status: "error", message: err.message })
    );
    return true; // keep message channel open for async
  }
});

// ---- Main bulk send logic ----
async function handleBulkSend() {
  const token = await getAccessToken(true);

  // 1️⃣ Get CSV + template
  const csvText = await getDriveFileContent(CSV_FILE_ID, token);
  const htmlTemplate = await getDriveFileContent(HTML_FILE_ID, token);

  // 2️⃣ Parse CSV (very simple parser: email,name,...)
  const rows = csvText
    .trim()
    .split(/\r?\n/)
    .slice(1) // skip header
    .map((line) => {
      const [email, name] = line.split(",");
      return { email: email.trim(), name: name.trim() };
    });

  // 3️⃣ Optional: select attachment from extension storage (future feature)
  const attachment = null;

  // 4️⃣ Send emails with small delay
  let count = 0;
  for (const row of rows) {
    if (!row.email) continue;
    const personalized = htmlTemplate.replace(/{{name}}/g, row.name);
    await sendEmail({
      to: row.email,
      subject: "Personalized Greetings",
      htmlBody: personalized,
      attachment,
      token,
    });
    count++;
    console.log(`Sent ${count}/${rows.length} → ${row.email}`);
    await new Promise((r) => setTimeout(r, 1500)); // delay 1.5s
  }

  console.log(`✅ Finished sending ${count} emails`);
}
